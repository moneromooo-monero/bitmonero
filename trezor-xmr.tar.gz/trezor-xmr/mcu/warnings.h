#ifndef __WARNINGS_H__
#define __WARNINGS_H__

#define DISABLE_VS_WARNINGS(w)

#endif