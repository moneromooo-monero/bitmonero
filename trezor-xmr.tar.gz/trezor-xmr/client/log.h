#if !defined(__LOG_H__)
#define __LOG_H__

#if 1
#define TLOG printf
#else
#define TLOG
#endif

#endif
