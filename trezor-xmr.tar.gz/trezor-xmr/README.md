# trezor-xmr
Copyright (c) 2014-2016, The Monero Project
